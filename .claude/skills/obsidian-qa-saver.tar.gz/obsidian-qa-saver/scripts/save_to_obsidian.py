#!/usr/bin/env python3
"""
Save formatted content to Obsidian vault with proper metadata.

Usage:
    python save_to_obsidian.py --vault-path /path/to/vault --folder "Topic" --title "Note Title" --content "content" --tags "tag1,tag2"
"""

import argparse
import os
import sys
from datetime import datetime
from pathlib import Path


def create_frontmatter(tags=None, links=None):
    """Create YAML frontmatter for Obsidian note.

    Args:
        tags: List of tags
        links: List of related links

    Returns:
        Formatted YAML frontmatter string
    """
    now = datetime.now()
    timestamp = now.strftime("%Y-%m-%d %H:%M")

    frontmatter = [
        "---",
        f"created: {timestamp}",
        f"updated: {timestamp}",
    ]

    if tags:
        frontmatter.append("tags:")
        for tag in tags:
            # Ensure tag format (remove # if present, convert to kebab-case)
            clean_tag = tag.strip().lstrip('#').lower().replace(' ', '-')
            frontmatter.append(f"  - {clean_tag}")

    frontmatter.append("aliases: []")
    frontmatter.append("---")

    return "\n".join(frontmatter)


def create_related_links(links):
    """Create related links section.

    Args:
        links: List of wiki links

    Returns:
        Formatted related links section
    """
    if not links:
        return ""

    section = ["\n**Related:**"]
    for link in links:
        # Ensure proper wiki link format
        if not link.startswith("[["):
            link = f"[[{link}]]"
        if not link.endswith("]]"):
            link = f"{link}]]"
        section.append(f"- {link}")

    section.append("")  # Empty line after links
    return "\n".join(section)


def sanitize_filename(title):
    """Sanitize title for use as filename.

    Args:
        title: Note title

    Returns:
        Safe filename
    """
    # Remove or replace invalid filename characters
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        title = title.replace(char, '-')

    # Remove leading/trailing spaces and dots
    title = title.strip('. ')

    return title


def save_note(vault_path, folder, title, content, tags=None, links=None):
    """Save note to Obsidian vault.

    Args:
        vault_path: Path to Obsidian vault
        folder: Folder within vault (can be nested: "parent/child")
        title: Note title
        content: Note content (markdown)
        tags: List of tags
        links: List of related wiki links

    Returns:
        Path to created note file
    """
    # Validate vault path
    vault_path = Path(vault_path)
    if not vault_path.exists():
        raise FileNotFoundError(f"Obsidian vault not found: {vault_path}")

    # Create folder path
    if folder:
        folder_path = vault_path / folder
        folder_path.mkdir(parents=True, exist_ok=True)
    else:
        folder_path = vault_path

    # Sanitize and create filename
    safe_title = sanitize_filename(title)
    note_path = folder_path / f"{safe_title}.md"

    # Check if file exists
    if note_path.exists():
        # Add timestamp to avoid conflicts
        timestamp = datetime.now().strftime("%Y-%m-%d-%H%M")
        note_path = folder_path / f"{safe_title} {timestamp}.md"

    # Build note content
    frontmatter = create_frontmatter(tags, links)
    related_links = create_related_links(links) if links else ""

    full_content = f"{frontmatter}\n{related_links}\n{content}\n"

    # Write note
    note_path.write_text(full_content, encoding='utf-8')

    return str(note_path)


def main():
    parser = argparse.ArgumentParser(
        description='Save formatted content to Obsidian vault'
    )
    parser.add_argument(
        '--vault-path',
        required=True,
        help='Path to Obsidian vault'
    )
    parser.add_argument(
        '--folder',
        default='',
        help='Folder within vault (optional)'
    )
    parser.add_argument(
        '--title',
        required=True,
        help='Note title'
    )
    parser.add_argument(
        '--content',
        required=True,
        help='Note content (markdown) or path to content file'
    )
    parser.add_argument(
        '--tags',
        default='',
        help='Comma-separated tags (optional)'
    )
    parser.add_argument(
        '--links',
        default='',
        help='Comma-separated wiki links for related notes (optional)'
    )

    args = parser.parse_args()

    # Parse tags
    tags = [t.strip() for t in args.tags.split(',') if t.strip()] if args.tags else None

    # Parse links
    links = [l.strip() for l in args.links.split(',') if l.strip()] if args.links else None

    # Get content
    content_path = Path(args.content)
    if content_path.exists() and content_path.is_file():
        # Content is a file path
        content = content_path.read_text(encoding='utf-8')
    else:
        # Content is direct string
        content = args.content

    try:
        # Save note
        note_path = save_note(
            vault_path=args.vault_path,
            folder=args.folder,
            title=args.title,
            content=content,
            tags=tags,
            links=links
        )

        print(f"SUCCESS: Note saved to {note_path}")
        return 0

    except FileNotFoundError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        print("\nPlease provide the correct path to your Obsidian vault.", file=sys.stderr)
        print("You can find this in Obsidian: Settings → Files & Links → Vault folder", file=sys.stderr)
        return 1

    except Exception as e:
        print(f"ERROR: Failed to save note: {e}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())