#!/usr/bin/env python3
"""
Database Seeding Script with ORM and Faker Support

This script provides a flexible framework for seeding any database with realistic
fake data using Faker library and ORM patterns.

Usage:
    python seed_database.py --config seed-config.yaml
    python seed_database.py --db postgresql --count 100 --models User,Post
    python seed_database.py --fixtures fixtures.json
"""

import argparse
import importlib
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Type

try:
    from faker import Faker
except ImportError:
    print("Error: Faker library not installed. Run: pip install faker")
    sys.exit(1)

try:
    import yaml
except ImportError:
    print("Warning: PyYAML not installed. YAML config support disabled.")
    yaml = None


class DatabaseSeeder:
    """Base class for database seeding operations"""

    def __init__(self, db_session=None, faker_locale: str = "en_US"):
        """
        Initialize the seeder

        Args:
            db_session: Database session (SQLAlchemy session, pymongo client, etc.)
            faker_locale: Locale for Faker data generation
        """
        self.session = db_session
        self.fake = Faker(faker_locale)
        self.created_objects = {}

    def seed_model(self, model_class: Type, count: int, factory_func: callable):
        """
        Seed a model with generated data

        Args:
            model_class: The ORM model class to seed
            count: Number of records to create
            factory_func: Function that generates model data

        Returns:
            List of created objects
        """
        created = []

        print(f"Seeding {count} {model_class.__name__} records...")

        for i in range(count):
            try:
                # Generate data using factory function
                data = factory_func(self.fake, i)

                # Create model instance
                obj = model_class(**data)

                # Add to session (works for SQLAlchemy)
                if hasattr(self.session, 'add'):
                    self.session.add(obj)

                created.append(obj)

                # Commit in batches for performance
                if (i + 1) % 100 == 0:
                    self._commit()
                    print(f"  Created {i + 1}/{count}...")

            except Exception as e:
                print(f"Error creating {model_class.__name__} #{i}: {e}")
                self._rollback()

        # Final commit
        self._commit()
        print(f"✓ Created {len(created)} {model_class.__name__} records")

        # Store for foreign key references
        self.created_objects[model_class.__name__] = created

        return created

    def seed_from_factory_dict(self, model_class: Type, count: int, factory_dict: Dict[str, Any]):
        """
        Seed using a dictionary-based factory definition

        Args:
            model_class: The ORM model class
            count: Number of records
            factory_dict: Dictionary mapping field names to Faker methods or callables

        Example:
            factory = {
                'name': lambda fake: fake.name(),
                'email': lambda fake: fake.email(),
                'age': lambda fake: fake.random_int(min=18, max=80)
            }
        """
        def factory_func(fake, index):
            data = {}
            for field, generator in factory_dict.items():
                if callable(generator):
                    data[field] = generator(fake)
                else:
                    data[field] = generator
            return data

        return self.seed_model(model_class, count, factory_func)

    def seed_from_fixtures(self, fixtures_path: str):
        """
        Seed database from JSON fixtures file

        Args:
            fixtures_path: Path to JSON fixtures file

        Fixture format:
            {
                "ModelName": [
                    {"field1": "value1", "field2": "value2"},
                    ...
                ]
            }
        """
        with open(fixtures_path, 'r', encoding='utf-8') as f:
            fixtures = json.load(f)

        for model_name, records in fixtures.items():
            print(f"Seeding {len(records)} {model_name} records from fixtures...")

            # Dynamically import model
            model_class = self._get_model_class(model_name)

            if not model_class:
                print(f"Warning: Model {model_name} not found, skipping...")
                continue

            created = []
            for record in records:
                try:
                    obj = model_class(**record)
                    if hasattr(self.session, 'add'):
                        self.session.add(obj)
                    created.append(obj)
                except Exception as e:
                    print(f"Error creating {model_name}: {e}")

            self._commit()
            print(f"✓ Created {len(created)} {model_name} records")

    def _commit(self):
        """Commit transaction"""
        if hasattr(self.session, 'commit'):
            self.session.commit()

    def _rollback(self):
        """Rollback transaction"""
        if hasattr(self.session, 'rollback'):
            self.session.rollback()

    def _get_model_class(self, model_name: str) -> Optional[Type]:
        """
        Dynamically import model class by name

        Args:
            model_name: Name of the model class

        Returns:
            Model class or None if not found
        """
        # Try common model locations
        locations = [
            'src.domain.models',
            'src.adapters.persistence.models',
            'app.models',
            'models',
        ]

        for location in locations:
            try:
                module = importlib.import_module(location)
                if hasattr(module, model_name):
                    return getattr(module, model_name)
            except (ImportError, AttributeError):
                continue

        return None


class SQLAlchemySeeder(DatabaseSeeder):
    """Seeder for SQLAlchemy-based databases"""

    @classmethod
    def from_engine(cls, engine, faker_locale: str = "en_US"):
        """Create seeder from SQLAlchemy engine"""
        from sqlalchemy.orm import sessionmaker

        Session = sessionmaker(bind=engine)
        session = Session()

        return cls(db_session=session, faker_locale=faker_locale)


class MongoDBSeeder(DatabaseSeeder):
    """Seeder for MongoDB databases"""

    def seed_collection(self, collection_name: str, count: int, factory_func: callable):
        """Seed a MongoDB collection"""
        print(f"Seeding {count} documents in {collection_name}...")

        documents = []
        for i in range(count):
            data = factory_func(self.fake, i)
            documents.append(data)

        # Insert in batches
        if hasattr(self.session, 'insert_many'):
            result = self.session[collection_name].insert_many(documents)
            print(f"✓ Inserted {len(result.inserted_ids)} documents")

        return documents


def load_config(config_path: str) -> Dict[str, Any]:
    """Load seeding configuration from YAML file"""
    if not yaml:
        raise RuntimeError("PyYAML not installed")

    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def create_seeder(db_type: str, connection_string: str, **kwargs) -> DatabaseSeeder:
    """
    Factory function to create appropriate seeder based on database type

    Args:
        db_type: Database type (postgresql, mysql, sqlite, mongodb)
        connection_string: Database connection string
        **kwargs: Additional arguments for seeder

    Returns:
        DatabaseSeeder instance
    """
    if db_type in ['postgresql', 'mysql', 'sqlite']:
        from sqlalchemy import create_engine
        engine = create_engine(connection_string)
        return SQLAlchemySeeder.from_engine(engine, **kwargs)

    elif db_type == 'mongodb':
        try:
            from pymongo import MongoClient
            client = MongoClient(connection_string)
            db_name = kwargs.get('database', 'test')
            return MongoDBSeeder(db_session=client[db_name], **kwargs)
        except ImportError:
            print("Error: pymongo not installed. Run: pip install pymongo")
            sys.exit(1)

    else:
        raise ValueError(f"Unsupported database type: {db_type}")


def main():
    parser = argparse.ArgumentParser(description="Database seeding with Faker and ORM")
    parser.add_argument('--config', help='Path to YAML configuration file')
    parser.add_argument('--db', help='Database type (postgresql, mysql, sqlite, mongodb)')
    parser.add_argument('--connection', help='Database connection string')
    parser.add_argument('--count', type=int, default=10, help='Number of records to create')
    parser.add_argument('--models', help='Comma-separated list of models to seed')
    parser.add_argument('--fixtures', help='Path to JSON fixtures file')
    parser.add_argument('--locale', default='en_US', help='Faker locale (default: en_US)')

    args = parser.parse_args()

    if args.config:
        # Load from configuration file
        config = load_config(args.config)
        db_type = config.get('database', {}).get('type')
        connection_string = config.get('database', {}).get('connection')
        seeder = create_seeder(db_type, connection_string, faker_locale=args.locale)

        # TODO: Implement config-based seeding
        print("Config-based seeding not yet implemented")

    elif args.fixtures:
        # Seed from fixtures
        if not args.db or not args.connection:
            print("Error: --db and --connection required when using --fixtures")
            sys.exit(1)

        seeder = create_seeder(args.db, args.connection, faker_locale=args.locale)
        seeder.seed_from_fixtures(args.fixtures)

    else:
        print("Error: Either --config or --fixtures required")
        parser.print_help()
        sys.exit(1)


if __name__ == '__main__':
    main()