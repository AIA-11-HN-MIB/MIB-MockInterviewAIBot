#!/usr/bin/env python3
"""
Database Configuration Detection Script

Automatically detects database type and connection details from:
- Environment variables
- Configuration files (.env, settings.py, config.yaml)
- Database URL patterns

Usage:
    python detect_db_config.py
    python detect_db_config.py --config-path src/infrastructure/config/settings.py
    python detect_db_config.py --env-file .env
"""

import argparse
import os
import re
import sys
from pathlib import Path
from typing import Dict, Optional, Tuple


class DatabaseConfigDetector:
    """Detects database configuration from various sources"""

    # Database URL patterns
    DB_URL_PATTERNS = {
        'postgresql': r'postgres(?:ql)?://([^:]+):([^@]+)@([^:/]+)(?::(\d+))?/(\w+)',
        'mysql': r'mysql://([^:]+):([^@]+)@([^:/]+)(?::(\d+))?/(\w+)',
        'sqlite': r'sqlite:///(.+)',
        'mongodb': r'mongodb://([^:]+):([^@]+)@([^:/]+)(?::(\d+))?/(\w+)',
    }

    # Common environment variable names
    ENV_VAR_PATTERNS = [
        'DATABASE_URL',
        'DB_URL',
        'SQLALCHEMY_DATABASE_URI',
        'POSTGRES_URL',
        'MONGODB_URI',
    ]

    # Config file patterns
    CONFIG_LOCATIONS = [
        '.env',
        '.env.local',
        'src/infrastructure/config/settings.py',
        'src/infrastructure/config/.env',
        'config/database.yml',
        'config.yaml',
    ]

    def __init__(self, project_root: Optional[Path] = None):
        """
        Initialize detector

        Args:
            project_root: Root directory of the project (defaults to cwd)
        """
        self.project_root = project_root or Path.cwd()

    def detect(self) -> Dict[str, str]:
        """
        Detect database configuration

        Returns:
            Dictionary with keys: type, connection, host, port, database, user
        """
        # Try environment variables first
        config = self._detect_from_env()
        if config:
            return config

        # Try configuration files
        config = self._detect_from_config_files()
        if config:
            return config

        # Try common locations in project structure
        config = self._detect_from_project_structure()
        if config:
            return config

        return {}

    def _detect_from_env(self) -> Optional[Dict[str, str]]:
        """Detect from environment variables"""
        for var_name in self.ENV_VAR_PATTERNS:
            db_url = os.getenv(var_name)
            if db_url:
                print(f"Found database URL in environment variable: {var_name}")
                return self._parse_database_url(db_url)

        # Check individual components
        db_type = os.getenv('DB_TYPE') or os.getenv('DATABASE_TYPE')
        if db_type:
            return {
                'type': db_type.lower(),
                'host': os.getenv('DB_HOST', 'localhost'),
                'port': os.getenv('DB_PORT', self._default_port(db_type)),
                'database': os.getenv('DB_NAME', 'test'),
                'user': os.getenv('DB_USER', 'root'),
                'password': os.getenv('DB_PASSWORD', ''),
            }

        return None

    def _detect_from_config_files(self) -> Optional[Dict[str, str]]:
        """Detect from configuration files"""
        for config_path in self.CONFIG_LOCATIONS:
            full_path = self.project_root / config_path

            if not full_path.exists():
                continue

            print(f"Checking config file: {config_path}")

            if config_path.endswith('.env'):
                config = self._parse_env_file(full_path)
            elif config_path.endswith('.py'):
                config = self._parse_python_config(full_path)
            elif config_path.endswith(('.yml', '.yaml')):
                config = self._parse_yaml_config(full_path)
            else:
                continue

            if config:
                return config

        return None

    def _detect_from_project_structure(self) -> Optional[Dict[str, str]]:
        """
        Detect from project structure analysis

        Looks for:
        - Alembic migrations (SQLAlchemy)
        - Django settings
        - Database files (SQLite)
        """
        # Check for SQLite databases
        sqlite_files = list(self.project_root.glob('*.db')) + \
                      list(self.project_root.glob('*.sqlite'))
        if sqlite_files:
            print(f"Found SQLite database: {sqlite_files[0]}")
            return {
                'type': 'sqlite',
                'connection': f'sqlite:///{sqlite_files[0]}',
                'database': str(sqlite_files[0]),
            }

        # Check for Alembic
        alembic_ini = self.project_root / 'alembic.ini'
        if alembic_ini.exists():
            config = self._parse_alembic_ini(alembic_ini)
            if config:
                return config

        return None

    def _parse_database_url(self, db_url: str) -> Optional[Dict[str, str]]:
        """Parse database URL into components"""
        for db_type, pattern in self.DB_URL_PATTERNS.items():
            match = re.match(pattern, db_url)
            if match:
                if db_type == 'sqlite':
                    return {
                        'type': 'sqlite',
                        'connection': db_url,
                        'database': match.group(1),
                    }
                else:
                    user, password, host, port, database = match.groups()
                    return {
                        'type': db_type,
                        'connection': db_url,
                        'host': host,
                        'port': port or self._default_port(db_type),
                        'database': database,
                        'user': user,
                        'password': password,
                    }

        return None

    def _parse_env_file(self, env_path: Path) -> Optional[Dict[str, str]]:
        """Parse .env file"""
        with open(env_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # Look for DATABASE_URL
        for var_name in self.ENV_VAR_PATTERNS:
            match = re.search(rf'^{var_name}=(.+)$', content, re.MULTILINE)
            if match:
                db_url = match.group(1).strip('"\'')
                return self._parse_database_url(db_url)

        return None

    def _parse_python_config(self, config_path: Path) -> Optional[Dict[str, str]]:
        """Parse Python configuration file"""
        with open(config_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # Look for database URL assignments
        patterns = [
            r'DATABASE_URL\s*=\s*["\'](.+)["\']',
            r'SQLALCHEMY_DATABASE_URI\s*=\s*["\'](.+)["\']',
        ]

        for pattern in patterns:
            match = re.search(pattern, content)
            if match:
                db_url = match.group(1)
                return self._parse_database_url(db_url)

        return None

    def _parse_yaml_config(self, config_path: Path) -> Optional[Dict[str, str]]:
        """Parse YAML configuration file"""
        try:
            import yaml
        except ImportError:
            print("Warning: PyYAML not installed, skipping YAML config")
            return None

        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)

        # Look for database configuration
        if 'database' in config:
            db_config = config['database']
            return {
                'type': db_config.get('type', 'postgresql'),
                'host': db_config.get('host', 'localhost'),
                'port': str(db_config.get('port', self._default_port(db_config.get('type', 'postgresql')))),
                'database': db_config.get('name', 'test'),
                'user': db_config.get('user', 'root'),
                'password': db_config.get('password', ''),
            }

        return None

    def _parse_alembic_ini(self, alembic_path: Path) -> Optional[Dict[str, str]]:
        """Parse alembic.ini for database URL"""
        with open(alembic_path, 'r', encoding='utf-8') as f:
            content = f.read()

        match = re.search(r'sqlalchemy\.url\s*=\s*(.+)', content)
        if match:
            db_url = match.group(1).strip()
            return self._parse_database_url(db_url)

        return None

    @staticmethod
    def _default_port(db_type: str) -> str:
        """Get default port for database type"""
        ports = {
            'postgresql': '5432',
            'mysql': '3306',
            'mongodb': '27017',
            'sqlite': '',
        }
        return ports.get(db_type.lower(), '5432')

    def format_connection_string(self, config: Dict[str, str]) -> str:
        """
        Format configuration into connection string

        Args:
            config: Database configuration dictionary

        Returns:
            Connection string
        """
        if 'connection' in config:
            return config['connection']

        db_type = config['type']

        if db_type == 'sqlite':
            return f"sqlite:///{config['database']}"

        user = config.get('user', 'root')
        password = config.get('password', '')
        host = config.get('host', 'localhost')
        port = config.get('port', self._default_port(db_type))
        database = config.get('database', 'test')

        if db_type == 'postgresql':
            return f"postgresql://{user}:{password}@{host}:{port}/{database}"
        elif db_type == 'mysql':
            return f"mysql://{user}:{password}@{host}:{port}/{database}"
        elif db_type == 'mongodb':
            return f"mongodb://{user}:{password}@{host}:{port}/{database}"

        return ""


def main():
    parser = argparse.ArgumentParser(description="Detect database configuration")
    parser.add_argument('--config-path', help='Path to specific config file')
    parser.add_argument('--env-file', help='Path to .env file')
    parser.add_argument('--project-root', help='Project root directory')

    args = parser.parse_args()

    project_root = Path(args.project_root) if args.project_root else Path.cwd()
    detector = DatabaseConfigDetector(project_root)

    if args.env_file:
        config = detector._parse_env_file(Path(args.env_file))
    elif args.config_path:
        config_path = Path(args.config_path)
        if config_path.suffix == '.py':
            config = detector._parse_python_config(config_path)
        elif config_path.suffix in ['.yml', '.yaml']:
            config = detector._parse_yaml_config(config_path)
        else:
            config = detector._parse_env_file(config_path)
    else:
        config = detector.detect()

    if config:
        print("\n✓ Database Configuration Detected:")
        print(f"  Type: {config.get('type', 'unknown')}")
        if 'host' in config:
            print(f"  Host: {config['host']}:{config.get('port', 'default')}")
        print(f"  Database: {config.get('database', 'N/A')}")

        connection_string = detector.format_connection_string(config)
        print(f"\n  Connection String:")
        # Mask password in output
        masked = re.sub(r':([^@:]+)@', ':****@', connection_string)
        print(f"  {masked}")

        # Output for script usage
        print(f"\n  Use with seed_database.py:")
        print(f"  python seed_database.py --db {config['type']} --connection \"{connection_string}\"")
    else:
        print("✗ No database configuration found")
        print("\nPlease ensure you have one of:")
        print("  - DATABASE_URL environment variable")
        print("  - .env file with database configuration")
        print("  - src/infrastructure/config/settings.py")
        sys.exit(1)


if __name__ == '__main__':
    main()