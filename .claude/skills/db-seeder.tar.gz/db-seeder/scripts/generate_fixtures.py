#!/usr/bin/env python3
"""
Generate Test Fixtures with Faker

Creates JSON fixtures with realistic fake data for testing purposes.

Usage:
    python generate_fixtures.py --output fixtures.json
    python generate_fixtures.py --models User:10,Post:50 --output test_data.json
    python generate_fixtures.py --template elios-interview --output elios_fixtures.json
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List

try:
    from faker import Faker
except ImportError:
    print("Error: Faker library not installed. Run: pip install faker")
    sys.exit(1)


class FixtureGenerator:
    """Generate test fixtures with Faker"""

    def __init__(self, faker_locale: str = "en_US"):
        """Initialize generator with Faker locale"""
        self.fake = Faker(faker_locale)

    def generate_user_fixtures(self, count: int) -> List[Dict[str, Any]]:
        """Generate user fixtures"""
        users = []
        for i in range(count):
            user = {
                'id': i + 1,
                'username': self.fake.user_name(),
                'email': self.fake.email(),
                'first_name': self.fake.first_name(),
                'last_name': self.fake.last_name(),
                'phone': self.fake.phone_number(),
                'date_of_birth': self.fake.date_of_birth(minimum_age=18, maximum_age=70).isoformat(),
                'address': {
                    'street': self.fake.street_address(),
                    'city': self.fake.city(),
                    'state': self.fake.state(),
                    'zip': self.fake.zipcode(),
                    'country': self.fake.country(),
                },
                'created_at': self.fake.date_time_between(start_date='-2y', end_date='now').isoformat(),
                'is_active': self.fake.boolean(chance_of_getting_true=80),
            }
            users.append(user)
        return users

    def generate_post_fixtures(self, count: int, user_count: int) -> List[Dict[str, Any]]:
        """Generate blog post fixtures"""
        posts = []
        for i in range(count):
            post = {
                'id': i + 1,
                'title': self.fake.sentence(nb_words=6),
                'slug': self.fake.slug(),
                'content': self.fake.text(max_nb_chars=2000),
                'author_id': self.fake.random_int(min=1, max=user_count),
                'published_at': self.fake.date_time_between(start_date='-1y', end_date='now').isoformat(),
                'views': self.fake.random_int(min=0, max=10000),
                'likes': self.fake.random_int(min=0, max=500),
                'tags': [self.fake.word() for _ in range(self.fake.random_int(min=1, max=5))],
                'is_published': self.fake.boolean(chance_of_getting_true=70),
            }
            posts.append(post)
        return posts

    def generate_candidate_fixtures(self, count: int) -> List[Dict[str, Any]]:
        """Generate interview candidate fixtures (Elios-specific)"""
        candidates = []

        skills_pool = [
            'Python', 'JavaScript', 'React', 'Node.js', 'SQL', 'MongoDB',
            'Docker', 'Kubernetes', 'AWS', 'Git', 'REST APIs', 'GraphQL',
            'Machine Learning', 'Data Science', 'FastAPI', 'Django',
        ]

        for i in range(count):
            # Random skills (2-6 skills per candidate)
            num_skills = self.fake.random_int(min=2, max=6)
            candidate_skills = self.fake.random_elements(
                elements=skills_pool,
                length=num_skills,
                unique=True
            )

            candidate = {
                'id': i + 1,
                'full_name': self.fake.name(),
                'email': self.fake.email(),
                'phone': self.fake.phone_number(),
                'years_of_experience': self.fake.random_int(min=0, max=15),
                'skills': list(candidate_skills),
                'education': {
                    'degree': self.fake.random_element(['Bachelor', 'Master', 'PhD']),
                    'major': self.fake.random_element([
                        'Computer Science', 'Software Engineering',
                        'Information Technology', 'Data Science'
                    ]),
                    'university': self.fake.company() + ' University',
                    'graduation_year': self.fake.random_int(min=2010, max=2024),
                },
                'cv_url': f"s3://bucket/cvs/candidate_{i+1}.pdf",
                'linkedin_url': f"https://linkedin.com/in/{self.fake.user_name()}",
                'github_url': f"https://github.com/{self.fake.user_name()}",
                'created_at': self.fake.date_time_between(start_date='-6m', end_date='now').isoformat(),
                'status': self.fake.random_element(['pending', 'interviewed', 'hired', 'rejected']),
            }
            candidates.append(candidate)

        return candidates

    def generate_question_fixtures(self, count: int) -> List[Dict[str, Any]]:
        """Generate interview question fixtures (Elios-specific)"""
        questions = []

        categories = ['technical', 'behavioral', 'system-design', 'coding']
        difficulties = ['easy', 'medium', 'hard']
        skills = ['Python', 'JavaScript', 'React', 'SQL', 'System Design', 'Algorithms']

        for i in range(count):
            question = {
                'id': i + 1,
                'text': self.fake.sentence(nb_words=10) + '?',
                'category': self.fake.random_element(categories),
                'difficulty': self.fake.random_element(difficulties),
                'related_skill': self.fake.random_element(skills),
                'expected_answer_keywords': [
                    self.fake.word() for _ in range(self.fake.random_int(min=3, max=8))
                ],
                'model_answer': self.fake.paragraph(nb_sentences=5),
                'evaluation_criteria': [
                    self.fake.sentence(nb_words=8)
                    for _ in range(self.fake.random_int(min=2, max=5))
                ],
                'time_limit_minutes': self.fake.random_element([5, 10, 15, 30]),
                'created_at': self.fake.date_time_between(start_date='-1y', end_date='now').isoformat(),
                'usage_count': self.fake.random_int(min=0, max=100),
            }
            questions.append(question)

        return questions

    def generate_interview_session_fixtures(
        self,
        count: int,
        candidate_count: int,
        question_count: int
    ) -> List[Dict[str, Any]]:
        """Generate interview session fixtures (Elios-specific)"""
        sessions = []

        for i in range(count):
            # Random number of questions (3-10 per session)
            num_questions = self.fake.random_int(min=3, max=10)

            # Generate answers for each question
            answers = []
            for _ in range(num_questions):
                answer = {
                    'question_id': self.fake.random_int(min=1, max=question_count),
                    'answer_text': self.fake.paragraph(nb_sentences=3),
                    'voice_recording_url': f"s3://bucket/recordings/session_{i+1}_q{_+1}.wav",
                    'duration_seconds': self.fake.random_int(min=30, max=600),
                    'score': self.fake.random_int(min=0, max=100),
                    'feedback': self.fake.sentence(nb_words=15),
                }
                answers.append(answer)

            session = {
                'id': i + 1,
                'candidate_id': self.fake.random_int(min=1, max=candidate_count),
                'started_at': self.fake.date_time_between(start_date='-3m', end_date='now').isoformat(),
                'completed_at': None if self.fake.boolean(chance_of_getting_true=20) else
                    (self.fake.date_time_between(start_date='-3m', end_date='now') +
                     timedelta(hours=1)).isoformat(),
                'status': self.fake.random_element(['in_progress', 'completed', 'cancelled']),
                'interview_type': self.fake.random_element(['technical', 'behavioral', 'mixed']),
                'answers': answers,
                'overall_score': self.fake.random_int(min=0, max=100),
                'feedback_summary': self.fake.paragraph(nb_sentences=5),
                'strengths': [
                    self.fake.sentence(nb_words=5) for _ in range(self.fake.random_int(min=2, max=4))
                ],
                'weaknesses': [
                    self.fake.sentence(nb_words=5) for _ in range(self.fake.random_int(min=1, max=3))
                ],
                'recommendations': self.fake.paragraph(nb_sentences=3),
            }
            sessions.append(session)

        return sessions

    def generate_elios_template(self) -> Dict[str, List[Dict[str, Any]]]:
        """Generate complete Elios interview system fixtures"""
        return {
            'Candidate': self.generate_candidate_fixtures(50),
            'Question': self.generate_question_fixtures(100),
            'InterviewSession': self.generate_interview_session_fixtures(
                count=30,
                candidate_count=50,
                question_count=100
            ),
        }


def main():
    parser = argparse.ArgumentParser(description="Generate test fixtures with Faker")
    parser.add_argument('--output', '-o', required=True, help='Output JSON file path')
    parser.add_argument('--models', help='Models and counts (e.g., User:10,Post:50)')
    parser.add_argument('--template', help='Use predefined template (elios-interview, blog)')
    parser.add_argument('--locale', default='en_US', help='Faker locale (default: en_US)')
    parser.add_argument('--pretty', action='store_true', help='Pretty-print JSON output')

    args = parser.parse_args()

    generator = FixtureGenerator(faker_locale=args.locale)
    fixtures = {}

    if args.template:
        if args.template == 'elios-interview':
            fixtures = generator.generate_elios_template()
        elif args.template == 'blog':
            fixtures = {
                'User': generator.generate_user_fixtures(20),
                'Post': generator.generate_post_fixtures(100, user_count=20),
            }
        else:
            print(f"Error: Unknown template '{args.template}'")
            sys.exit(1)

    elif args.models:
        # Parse models and counts
        for model_spec in args.models.split(','):
            model_name, count = model_spec.split(':')
            count = int(count)

            if model_name.lower() == 'user':
                fixtures['User'] = generator.generate_user_fixtures(count)
            elif model_name.lower() == 'post':
                fixtures['Post'] = generator.generate_post_fixtures(count, user_count=count)
            elif model_name.lower() == 'candidate':
                fixtures['Candidate'] = generator.generate_candidate_fixtures(count)
            elif model_name.lower() == 'question':
                fixtures['Question'] = generator.generate_question_fixtures(count)
            elif model_name.lower() == 'interviewsession':
                fixtures['InterviewSession'] = generator.generate_interview_session_fixtures(
                    count=count,
                    candidate_count=50,
                    question_count=100
                )
            else:
                print(f"Warning: Unknown model '{model_name}', skipping...")

    else:
        print("Error: Either --models or --template required")
        parser.print_help()
        sys.exit(1)

    # Write fixtures to file
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, 'w', encoding='utf-8') as f:
        if args.pretty:
            json.dump(fixtures, f, indent=2, ensure_ascii=False)
        else:
            json.dump(fixtures, f, ensure_ascii=False)

    # Print summary
    print(f"\n✓ Generated fixtures: {output_path}")
    for model_name, records in fixtures.items():
        print(f"  - {model_name}: {len(records)} records")


if __name__ == '__main__':
    main()